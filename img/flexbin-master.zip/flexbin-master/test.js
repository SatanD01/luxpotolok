var open = require('open');

open('test.html');
